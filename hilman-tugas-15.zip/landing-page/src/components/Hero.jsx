import styled from 'styled-components'

function Hero(){
const title = [
    'nama lengkap',
    'asal',
    'umur',
    'status',
]
const user = [
    'muhammad ariel',
    'bogor',
    '31 tahun',
    'lajang',
]

const Sayang = styled.h5`
background-color: aqua;
`

const Cuaks = styled.div`
background-color: green;
`
return (
    <>
      <Cuaks>
        <Sayang>{title[0]}</Sayang>
        <h3>{user[0]}</h3><br/>

        <Sayang>{title[1]}</Sayang>
        <h3>{user[1]}</h3><br/>

        <Sayang>{title[2]}</Sayang>
        <h3>{user[2]}</h3><br/>

        <Sayang>{title[3]}</Sayang>
        <h3>{user[3]}</h3><br/>
      </Cuaks>
    </>
)
}
export default Hero