import styled from "styled-components"

function Navbar(){
    let title = "my landing page"

    const Ua = styled.h2`
    background-color: yellow;
    `

    return(
        <>
        <div>

             <Ua>{title}</Ua>

        </div>
        </>
    )
}

export default Navbar